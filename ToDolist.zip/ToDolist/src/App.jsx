import React, { useReducer } from "react";
import { Reducer } from "./Store/reducerfile";
import "./App.css";

const initialState = {
  todos: [],
};

function TodoList() {
  const [state, dispatch] = useReducer(Reducer, initialState);
  const addTodo = (todoText) => {
    dispatch({
      type: "ADD_TODO",
      payload: { id: Date.now(), text: todoText, completed: false },
    });
  };


  

  const toggleTodo = (todoId) => {
    dispatch({
      type: "TOGGLE_TODO",
      payload: todoId,
    });
  };

  const removeTodo = (todoId) => {
    dispatch({
      type: "REMOVE_TODO",
      payload: todoId,
    });
  };

  return (
    <div className="main">
      <h2>Todo List</h2>
      <input type="text" id="todoInput" />
      <button
        onClick={() => addTodo(document.getElementById("todoInput").value)}
      >
        Add Todo
      </button>
      <ul>
        {state.todos.map((todo) => (
          <li key={todo.id}>
            {todo.text}

            {todo.completed ? (
              <span
                style={{ background: "green" }}
                onClick={() => toggleTodo(todo.id)}
              >
                Done
              </span>
            ) : (
              <span
                style={{ background: "red" }}
                onClick={() => toggleTodo(todo.id)}
              >
                not done
              </span>
            )}

            <button onClick={() => removeTodo(todo.id)}>Remove</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default TodoList;
