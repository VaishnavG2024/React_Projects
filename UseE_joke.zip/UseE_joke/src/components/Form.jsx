import React, {useRef,useState}  from 'react';
import FormDisplay from './FormDisplay';
import  '../App.css';



function Form() {
    let [id,setid]=useState();
    let [passd, setpassd]=useState();
    const userid= useRef();
    const password = useRef();
    
   function handlOnclick(e){
    e.preventDefault();
    console.log(userid.current.value);
    console.log(password.current.value);
    console.log(userid.current);
    setid(userid.current.value)
    setpassd(password.current.value)
    console.log(id);
}


  return (
   <>
   <div className="mainFormBx">
    <div className="formBox">
        <div>
        <label htmlFor="username" >User ID: </label><br />
         <input type="text" id="username" ref={userid} name="username" placeholder='Enter UserID' /><br/>
    </div>
    <div>
            <label htmlFor="pwd">Password:</label><br />
            <input type="password" id="pwd" ref={password} name="password" placeholder="Enter Password"/><br />
    </div>
    
        <br />
        <br />
    

    <div className="btn">
        <button onClick={(e)=> handlOnclick(e)}>Login</button>
    </div>
   </div>
    <div className="displayBox"></div>

      <FormDisplay id={id} passd={passd}/>

   </div> 
   </>
  )
}

export default Form