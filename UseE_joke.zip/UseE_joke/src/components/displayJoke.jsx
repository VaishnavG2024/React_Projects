import React, { useEffect, useState } from 'react'

function displayJoke({call}) {
    let [joke, setJoke] = useState();
    let [punch, setPunch] = useState();
    
    useEffect( () => {

        async function apicall(){
            try{
                const res= await  fetch("https://official-joke-api.appspot.com/random_joke");
                const data=await res.json();
                setJoke (data.setup);
                setPunch(data.punchline)
                console.log(data)

            }catch(err){
                console.log('error', err);
        }
        }
         apicall();
    }, [call]);

    return(
        <>
        <div className="Mainbox">
            <p> Joke: {joke}</p>
        </div>

        <div className="Mainbox2">
        <p> Punchline: {punch}</p>
        </div>
        </>   
    )
}

export default displayJoke
