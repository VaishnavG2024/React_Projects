import React from 'react'

function btnJoke({call, setcall}) {

  return (
    <>
    <div className="jokebtn">
        <buttin onClick={()=> setcall(!call)}>Next Joke</buttin>
    </div>
    
    </>
  )
}

export default btnJoke
