
import React from 'react'

function FormDisplay(props) {


  return (
    <div>

        <p>Emai Id:    {props.id} </p> 
        <p>Pssword:    {props.passd}</p>

    </div>
  )
}

export default FormDisplay
