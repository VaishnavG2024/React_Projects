import { useState } from 'react'
import './App.css'
import DisplayJoke  from './components/displayJoke'
import BtnJoke  from './components/btnJoke'

function App() {
  const [call, setcall] = useState(false)

  return (

    <>
    <div className="container">
      <DisplayJoke  call={call}/>
      <BtnJoke setcall= {setcall} call= {call} />
    </div> 
    </>
  )
}

export default App






// ----------------------------------------------Login Form------------------------------------------

// import React from 'react'
// import Form from './components/Form';

// function App() {
//   return (
//     <div>
//       <Form/>
//     </div>
//   );
// }

// export default App

