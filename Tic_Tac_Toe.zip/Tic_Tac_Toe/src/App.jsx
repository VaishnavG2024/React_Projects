import "./App.css";
import FrontPage from "./Components/FrontPage";
import TicTacToe from "./Components/Game";
import React, { useState } from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import Submain from "./Submain";
import Button from "react-bootstrap/Button";

function App() {
  const [showPage, setShowPage] = useState(false);
 

  const [show, setShow] = useState(false);
  const handleClose = () => setShow(false);

  const handleShow = () => setShow(true);

  function handleonStart() {
  
    handleShow();
    setShowPage(true);
  }
  return (
    <>
      {show ? (
        null
      ) : <div className="container">
      <h1>Welcome to TicTacToe!</h1>
      <button
        className="button"
        variant="primary"
        onClick={() => handleonStart()}
      >
        {" "}
        Let's Start!!!{" "}
      </button>
    </div>}

      <Submain
        className="button"
        variant="primary"
        handleClose={handleClose}
        handleShow={handleShow}
        show={show}
        setShow={setShow}
      >
        TicTacToe
      </Submain>

      {showPage && <TicTacToe />}
    </>
  );
}

export default App;
