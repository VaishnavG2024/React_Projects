import React from 'react'
import style from "./Game.module.css";

function Sqrbtn({value,onClick}) {
  return (
    <button onClick={onClick} className={style.btn}>
        {value}
      
    </button>
  )
}

export default Sqrbtn;
