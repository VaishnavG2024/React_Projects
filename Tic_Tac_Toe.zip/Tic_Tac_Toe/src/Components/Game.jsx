import React, {useEffect,useState} from 'react';
import Sqrbtn from './Sqrbtn';
import style from "./Game.module.css";
import Submain from '../Submain'

function TicTacToe({playername}) {
    const [square,setsquare]=useState(Array(9).fill(""));
    const [xTurn,setxTurn]=useState(true);
    const [status,setstatus]=useState("");

    

    function handleOnClick(getCurrentid){
        let cpySquare=[...square];

       if(getWinner(cpySquare) || cpySquare[getCurrentid]) return;
       cpySquare[getCurrentid]=xTurn ? "X" : "O";
       setxTurn(!xTurn);
       setsquare(cpySquare);
    }

    function  getWinner(){
        const winningpatterns =[

            [0,1,2],
            [3,4,5],
            [6,7,8],
            [0,3,6],
            [1,4,7],
            [2,5,8],
            [0,4,8],
            [2,4,6],

        ];

        for(let i=0; i < winningpatterns.length; i++){
            const [x,y,z]=winningpatterns[i];

          if(square[x] && square[x]===square[y] && square[x]===square[z]){
            return square[x];
          }  
        }
        return null;
    }


    useEffect(()=>{
        if(!getWinner(square) && square.every((item) => item !=="")){
            setstatus(`This is draw ! please Restart the game`);
        }else if(getWinner(square)){
            setstatus(`Winner is ${xTurn ? "X": "O"}`);
        }else {
            setstatus(`Next Player is${xTurn ? "X": "O"}`);
        }

    },[square,xTurn,playername]);


    function RestartGame()
    {
        setxTurn(true);
        setsquare(Array(9).fill(""));
    }


  return (
   <>
        <div className={style.mainBox}>
            <div className={style.TicTacToeContainer}>
                <div className={style.row}>
                    <Sqrbtn value={square[0]} onClick={()=> handleOnClick(0)}/>
                    <Sqrbtn value={square[1]} onClick={()=> handleOnClick(1)}/>
                    <Sqrbtn value={square[2]} onClick={()=> handleOnClick(2)}/>
                </div>
                <div className={style.row}>
                    <Sqrbtn value={square[3]} onClick={()=> handleOnClick(3)}/>
                    <Sqrbtn value={square[4]} onClick={()=> handleOnClick(4)}/>
                    <Sqrbtn value={square[5]} onClick={()=> handleOnClick(5)}/>
                </div>
                <div className={style.row}>
                    <Sqrbtn value={square[6]} onClick={()=> handleOnClick(6)}/>
                    <Sqrbtn value={square[7]} onClick={()=> handleOnClick(7)}/>
                    <Sqrbtn value={square[8]} onClick={()=> handleOnClick(8)}/>
                </div>
            </div>
       
        <div className={style.infoOfGame}>
            <h2>{status}</h2>
            
            <button onClick={()=> RestartGame()}>Restart Game</button>
        </div>
 </div>
   </>
  );
}

export default TicTacToe;
