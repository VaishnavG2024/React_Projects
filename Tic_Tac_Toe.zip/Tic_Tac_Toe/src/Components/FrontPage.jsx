import React from 'react'


function FrontPage({onClick,setPlayerName}) {

  return (
    <>
 
    </>
  )
}

export default FrontPage
