// import React, { useState } from 'react'
// import './App.css'

// function App() {
//   const [products, setProduct] = useState([]);
  
//   // Fetch data from API in (synchronous way) 
//   function product() {
//     fetch('https://dummyjson.com/products')
//     .then(res => res.json())
//     .then((data)=>{
//     setProduct(data.products)
//    }).catch((error)=> console.log(error))
    
//   }
  
//   product()

 
//   return (
//     <>
//       <div className='container'>
//         <h1>Product Section </h1>
//         <div id='mydiv'>
//           {products.map((CurPrice) => (
//             <div key={CurPrice.id} className='product'>
//               <img src={CurPrice.images[0]
//             } alt={CurPrice.title}/>
//               <h2>{CurPrice.title}</h2>
//               <h4>  Selling Price: 5000 {CurPrice.sellingprice}</h4>
//         </div>
//           ))}
//         </div>
//         </div>
     
//     </>
//   )
// }

// export default App


import {useEffect, useState} from 'react';
import "./App.css"

function App() {
  const[weather,setWeather]=useState({})
  function weatherdata(data){
    //console.log(data);
    setWeather(data);
  }
  useEffect(()=>{
    async function apiCall(){
      let res= await fetch("https://api.openweathermap.org/data/2.5/weather?q=nagpur&appid=19adbda7217674f2cf97a4c1340ad9cd");
  
      let data=await res.json();
      // setweather(data);
      weatherdata(data);
  }
  apiCall();
},[])

console.log(weather);

  return (
    <>
    <div>
      Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ad deleniti mollitia ullam facilis sapiente rerum quia dignissimos corporis, aspernatur inventore corrupti ducimus laborum tempora in non facere eligendi quae similique!
      <h1>{weather.main.temp}</h1>
      {/* <h1>{weather.main.wind}</h1> */}
      
    </div>
    </>
  )
}

export default App


